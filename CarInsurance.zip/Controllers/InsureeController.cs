using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using CarInsurance.Models;

namespace CarInsurance.Controllers
{
    public class InsureeController : Controller
    {
        private InsuranceEntities db = new InsuranceEntities();

        public ActionResult Index()
        {
            return View(db.Insurees.ToList());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Insuree insuree)
        {
            if (ModelState.IsValid)
            {
                decimal quote = 50;
                int age = DateTime.Now.Year - insuree.DateOfBirth.Year;
                if (insuree.DateOfBirth > DateTime.Now.AddYears(-age)) age--;

                if (age <= 18) quote += 100;
                else if (age >= 19 && age <= 25) quote += 50;
                else quote += 25;

                if (insuree.CarYear < 2000) quote += 25;
                if (insuree.CarYear > 2015) quote += 25;

                if (insuree.CarMake.ToLower() == "porsche") quote += 25;
                if (insuree.CarMake.ToLower() == "porsche" && insuree.CarModel.ToLower().Contains("911 carrera")) quote += 25;

                quote += insuree.SpeedingTickets * 10;

                if (insuree.DUI) quote += quote * 0.25m;
                if (insuree.CoverageType) quote += quote * 0.5m;

                insuree.Quote = quote;
                db.Insurees.Add(insuree);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(insuree);
        }

        public ActionResult Admin()
        {
            return View(db.Insurees.ToList());
        }
    }
}
